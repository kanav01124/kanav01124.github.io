

// Function to fetch trivia questions from the API
async function fetchTriviaQuestions(difficulty, numQuestions) {
    const url = `https://opentdb.com/api.php?amount=10&difficulty=medium`;
    console.log('Fetching questions from:', url); // Add this line to log the URL
    try {
        const response = await fetch(url);
        if (!response.ok) {
            throw new Error('Failed to fetch questions');
        }
        const data = await response.json();
        console.log('Fetched data:', data); // Add this line to log the fetched data
        return data.results; // Assuming data.results contains an array of trivia questions
    } catch (error) {
        console.error('Error fetching trivia questions:', error);
        return []; // Return an empty array in case of an error
    }
}

// Function to display the next question
async function displayNextQuestion() {
    const currentQuestion = await getNextQuestion();
    if (currentQuestion) {
        // Display the question on the UI
        document.getElementById('question-text').innerText = currentQuestion.question;
        // Display the answers
        displayAnswers(currentQuestion.incorrect_answers.concat(currentQuestion.correct_answer));
        //Update progress bar
        updateProgressBar()
    } else {
        // Handle case when there are no more questions
        console.log('No more questions.');
    }
}

// Function to get the next question from the fetched questions array
let questions = [];
let questionIndex = 0;
async function getNextQuestion() {
    if (questions && questionIndex < questions.length) {
        return questions[questionIndex++];
    } else {
        // Fetch more questions if the current batch is exhausted
        questions = await fetchTriviaQuestions();
        questionIndex = 0;
        return questions[questionIndex++];
    }
}

// Function to start the game and display the first question
async function startGame() {
    const difficulty = document.getElementById('difficulty').value;
    const numQuestions = document.getElementById('num-questions').value;
    // Validate numQuestions to ensure it's within a reasonable range
    if (numQuestions < 1 || numQuestions > 50) {
        alert('Please enter a number of questions between 1 and 50.');
        return;
    }
    // Hide the start screen
    document.getElementById('start-screen').classList.add('hide');
    // Display the trivia screen
    document.getElementById('trivia-screen').classList.remove('hide');
    // Fetch trivia questions with the selected difficulty and number
    questions = await fetchTriviaQuestions(difficulty, numQuestions);
    // Reset question index
    questionIndex = 0;
    // Display the first question
    displayNextQuestion();
}


// Example usage of startGame function
document.getElementById('start-button').addEventListener('click', startGame);

document.getElementById('next-button').addEventListener('click', () => {
    if (questionIndex < questions.length-1) {
        questionIndex++;
        displayNextQuestion();
        document.getElementById('feedback').classList.add('hide'); // Hide feedback when moving to next question
        updateProgressBar();
    } else {
        console.log('No more questions.');
        document.getElementById('next-button').disabled = true;
    }
});

// Function to display answer buttons
function displayAnswers(answers) {
    const answerButtonsContainer = document.getElementById('answer-buttons');
    answerButtonsContainer.innerHTML = ''; // Clear previous buttons
    answers.forEach((answer, index) => {
        const button = document.createElement('button');
        button.innerText = answer;
        button.classList.add('btn');
        button.addEventListener('click', () => selectAnswer(answer));
        answerButtonsContainer.appendChild(button);
    });
}

// Function to handle answer selection
function selectAnswer(answer) {
    const feedbackElement = document.getElementById('feedback');
    if (answer === questions[questionIndex - 1].correct_answer) {
        feedbackElement.innerText = 'Correct! 😊';
        feedbackElement.classList.add('correct');
    } else {
        feedbackElement.innerText = 'Incorrect! 😞';
        feedbackElement.classList.add('incorrect');
    }
    feedbackElement.classList.remove('hide');
}

// Function to update the progress bar
function updateProgressBar() {
    const progressBar = document.getElementById('progress-bar');
    const progress = ((questionIndex + 1) / questions.length) * 100; // Add 1 to questionIndex because it starts from 0
    progressBar.style.width = progress + '%';
}
// Add an event listener to the difficulty selection dropdown
document.getElementById('difficulty').addEventListener('change', function() {
    // Get the selected difficulty
    var selectedDifficulty = document.getElementById('difficulty').value;
    console.log('Selected difficulty:', selectedDifficulty); // Debugging statement
    // Update the text content of the difficulty tag
    document.getElementById('question-difficulty').innerText = selectedDifficulty;
});
