document.getElementById('start-button').addEventListener('click', startGame);
document.getElementById('next-button').addEventListener('click', () => {
    if (currentQuestionIndex < questions.length - 1) {
        currentQuestionIndex++;
        setNextQuestion();
    }
});
document.getElementById('prev-button').addEventListener('click', () => {
    if (currentQuestionIndex > 0) {
        currentQuestionIndex--;
        setNextQuestion();
    }
});

let currentQuestionIndex = 0;

const questions = [
    {
        text: "Which planet is known as the Red Planet?",
        category: "Science & Nature",
        difficulty: "Easy",
        answers: [
            { text: "Earth", correct: false },
            { text: "Mars", correct: true },
            { text: "Jupiter", correct: false },
            { text: "Venus", correct: false }
        ]
    },
    {
        text: "Which planet is known as the dead Planet?",
        category: "Science & Nature",
        difficulty: "Easy",
        answers: [
            { text: "Earth", correct: false },
            { text: "Pluto", correct: true },
            { text: "Jupiter", correct: false },
            { text: "Venus", correct: false }
        ]
    },
    {
        text: "Which planet is known as the blue planet?",
        category: "Science & Nature",
        difficulty: "Easy",
        answers: [
            { text: "Earth", correct: false },
            { text: "Venus", correct: true },
            { text: "Jupiter", correct: false },
            { text: "Neptune", correct: false }
        ]
    },
    {
        text: "There are 8 planets in our solar system?",
        category: "Science & Nature",
        difficulty: "Easy",
        answers: [
            { text: "True", correct: true },
            { text: "False", correct: false },
            
        ]
    },
    
];

function startGame() {
    document.getElementById('start-screen').classList.add('hide');
    document.getElementById('trivia-screen').classList.remove('hide');
    setNextQuestion();
}

function setNextQuestion() {
    resetState();
    showQuestion(questions[currentQuestionIndex]);
    updateProgressBar();
}

function showQuestion(question) {
    document.getElementById('question-category').innerText = question.category;
    document.getElementById('question-difficulty').innerText = question.difficulty;
    document.getElementById('question-text').innerText = question.text;
    question.answers.forEach(answer => {
        const button = document.createElement('button');
        button.innerText = answer.text;
        button.classList.add('btn');
        button.addEventListener('click', () => selectAnswer(answer));
        document.getElementById('answer-buttons').appendChild(button);
    });
}

function resetState() {
    const answerButtons = document.getElementById('answer-buttons');
    while (answerButtons.firstChild) {
        answerButtons.removeChild(answerButtons.firstChild);
    }
    document.getElementById('feedback').classList.add('hide');
    document.getElementById('feedback').innerText = '';
}

function selectAnswer(answer) {
    const feedbackElement = document.getElementById('feedback');
    if (answer.correct) {
        feedbackElement.innerText = 'Correct! 😊';
        feedbackElement.classList.add('correct');
    } else {
        feedbackElement.innerText = 'Incorrect! 😞';
        feedbackElement.classList.add('incorrect');
    }
    feedbackElement.classList.remove('hide');
}

function updateProgressBar() {
    const progressBar = document.getElementById('progress-bar');
    const progress = ((currentQuestionIndex + 1) / questions.length) * 100;
    progressBar.style.width = progress + '%';
}
